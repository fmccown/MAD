The Pet Adoption starter project is from the Mobile Application Development with Android and Jetpack Compose zyBook.

Pet images are from Flickr and are open domain.